#ifndef DATE_H
#define DATE_H

#include <stdint.h>

typedef uint64_t date_t; // 0xYYYYMMDD
#define DATE_NULL (date_t)0

date_t date_new(int year, int month, int day);
int date_cmp(date_t a, date_t b);
char *date_to_str(date_t date);

#endif