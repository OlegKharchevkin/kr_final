#include "task.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TASKS_ARR_START_CAPACITY 16

task_t *task_new(char *name, date_t deadline, status_t status, priority_t priority)
{
    task_t *task = malloc(sizeof(task_t));
    task->name = malloc(strlen(name) + 1);
    strcpy(task->name, name);
    task->deadline = deadline;
    task->status = status;
    task->priority = priority;
    return task;
}

void task_free(task_t *task)
{
    free(task->name);
    free(task);
}

static tasks_arr_t tasks_arr_extend(tasks_arr_t tasks)
{
    if (!tasks.items)
        return (tasks_arr_t){NULL, 0, 0};
    if (tasks.len + 1 >= tasks.cap)
    {
        task_t **tmp = realloc(tasks.items, (tasks.cap * 2) * sizeof(task_t *));
        if (!tmp)
            return (tasks_arr_t){NULL, 0, 0};
        tasks.items = tmp;
        tasks.cap *= 2;
    }
    return tasks;
}

tasks_arr_t tasks_arr_new(size_t cap)
{
    tasks_arr_t arr = {
        malloc(cap * sizeof(task_t *)),
        0,
        cap};
    return arr;
}

void tasks_arr_free(tasks_arr_t tasks)
{
    if (!tasks.items)
        return;
    for (size_t i = 0; i < tasks.len; i++)
    {
        if (tasks.items[i])
            task_free(tasks.items[i]);
    }
    free(tasks.items);
}

tasks_arr_t tasks_arr_append(tasks_arr_t tasks, char *name, date_t deadline,
                             status_t status, priority_t priority)
{
    task_t *new_task = task_new(name, deadline, status, priority);
    if (!new_task)
        return (tasks_arr_t){NULL, 0, 0};

    tasks_arr_t tmp = tasks_arr_extend(tasks);
    if (!tmp.items)
    {
        task_free(new_task);
        return (tasks_arr_t){NULL, 0, 0};
    }
    tmp.items[tmp.len] = new_task;
    tmp.len++;
    return tmp;
}

static int task_comp_priority(const void *a, const void *b)
{
    const task_t *ta = *(const task_t **)a;
    const task_t *tb = *(const task_t **)b;
    if (ta->priority < tb->priority)
        return -1;
    if (ta->priority > tb->priority)
        return 1;
    return 0;
}

tasks_arr_t tasks_arr_sort_priority(tasks_arr_t tasks)
{
    if (tasks.items && tasks.len > 1)
    {
        qsort(tasks.items, tasks.len, sizeof(task_t *), task_comp_priority);
    }
    return tasks;
}

tasks_arr_t tasks_arr_filter_status(tasks_arr_t tasks, status_t status)
{
    tasks_arr_t result = tasks_arr_new(TASKS_ARR_START_CAPACITY);
    if (!result.items)
        return (tasks_arr_t){NULL, 0, 0};

    for (size_t i = 0; i < tasks.len; i++)
    {
        if (tasks.items[i]->status == status)
        {
            tasks_arr_t tmp = tasks_arr_extend(result);
            if (!tmp.items)
            {
                tasks_arr_free(result);
                return (tasks_arr_t){NULL, 0, 0};
            }
            result = tmp;
            result.items[result.len++] = tasks.items[i];
        }
    }
    return result;
}

tasks_arr_t tasks_arr_filter_priority(tasks_arr_t tasks, priority_t priority)
{
    tasks_arr_t result = tasks_arr_new(TASKS_ARR_START_CAPACITY);
    if (!result.items)
        return (tasks_arr_t){NULL, 0, 0};

    for (size_t i = 0; i < tasks.len; i++)
    {
        if (tasks.items[i]->priority == priority)
        {
            tasks_arr_t tmp = tasks_arr_extend(result);
            if (!tmp.items)
            {
                tasks_arr_free(result);
                return (tasks_arr_t){NULL, 0, 0};
            }
            result = tmp;
            result.items[result.len++] = tasks.items[i];
        }
    }
    return result;
}

tasks_arr_t tasks_arr_filter_overdue(tasks_arr_t tasks, date_t today)
{
    tasks_arr_t result = tasks_arr_new(TASKS_ARR_START_CAPACITY);
    if (!result.items)
        return (tasks_arr_t){NULL, 0, 0};

    for (size_t i = 0; i < tasks.len; i++)
    {
        task_t *t = tasks.items[i];
        if (t->deadline != DATE_NULL && date_cmp(t->deadline, today) < 0)
        {
            tasks_arr_t tmp = tasks_arr_extend(result);
            if (!tmp.items)
            {
                tasks_arr_free(result);
                return (tasks_arr_t){NULL, 0, 0};
            }
            result = tmp;
            result.items[result.len++] = t;
        }
    }
    return result;
}

tasks_arr_t tasks_arr_filter_highest_priority(tasks_arr_t tasks)
{
    if (tasks.len == 0)
        return tasks_arr_new(0);

    priority_t highest = tasks.items[0]->priority;
    for (size_t i = 1; i < tasks.len; i++)
    {
        if (tasks.items[i]->priority < highest)
            highest = tasks.items[i]->priority;
    }
    return tasks_arr_filter_priority(tasks, highest);
}


static const char *priority_to_str(priority_t p)
{
    switch (p)
    {
    case 1:
        return "HIGH";
    case 2:
        return "MEDIUM";
    case 3:
        return "LOW";
    default:
        return "UNKNOWN";
    }
}

static const char *status_to_str(status_t s)
{
    switch (s)
    {
    case 1:
        return "TODO";
    case 2:
        return "IN_PROGRESS";
    case 3:
        return "DONE";
    default:
        return "UNKNOWN";
    }
}

void tasks_arr_print(tasks_arr_t tasks, date_t today)
{
    if (tasks.len == 0)
    {
        printf("No tasks.\n");
        return;
    }

    size_t max_index = 2; 
    size_t temp = tasks.len;
    while (temp > 0)
    {
        max_index++;
        temp /= 10;
    }

    size_t max_name = 4;  
    size_t max_deadline = 8;
    size_t max_status = 6;  
    size_t max_priority = 8; 

    for (size_t i = 0; i < tasks.len; i++)
    {
        size_t name_len = strlen(tasks.items[i]->name);
        if (name_len > max_name)
            max_name = name_len;

        const char *stat_str = status_to_str(tasks.items[i]->status);
        size_t stat_len = strlen(stat_str);
        if (stat_len > max_status)
            max_status = stat_len;

        const char *prio_str = priority_to_str(tasks.items[i]->priority);
        size_t prio_len = strlen(prio_str);
        if (prio_len > max_priority)
            max_priority = prio_len;

        if (tasks.items[i]->deadline != DATE_NULL)
        {
            char *dstr = date_to_str(tasks.items[i]->deadline);
            size_t dlen = strlen(dstr);
            if (dlen > max_deadline)
                max_deadline = dlen;
            free(dstr);
        }
        else
        {
            const char *none = "None";
            if (strlen(none) > max_deadline)
                max_deadline = strlen(none);
        }
    }

    printf("%-*s  %-*s  %-*s  %-*s  %-*s\n",
           (int)max_index, "ID",
           (int)max_name, "Name",
           (int)max_deadline, "Deadline",
           (int)max_status, "Status",
           (int)max_priority, "Priority");

    size_t total = max_index + 2 + max_name + 2 + max_deadline + 2 + max_status + 2 + max_priority;
    for (size_t i = 0; i < total; i++)
        putchar('-');
    putchar('\n');

    for (size_t i = 0; i < tasks.len; i++)
    {
        task_t *t = tasks.items[i];
        char *deadline_str = NULL;
        if (t->deadline != DATE_NULL)
        {
            deadline_str = date_to_str(t->deadline);
        }
        printf("%-*zu  %-*s  %-*s  %-*s  %-*s\n",
               (int)max_index, i + 1,
               (int)max_name, t->name,
               (int)max_deadline, deadline_str ? deadline_str : "None",
               (int)max_status, status_to_str(t->status),
               (int)max_priority, priority_to_str(t->priority));
        if (deadline_str)
            free(deadline_str);
    }

    for (size_t i = 0; i < total; i++)
        putchar('-');
    putchar('\n');
}