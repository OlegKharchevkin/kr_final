#include "date.h"
#include "stdio.h"
#include "stdlib.h"

date_t date_new(int year, int month, int day)
{
    return ((year & 0xFFFF) << 16) | ((month & 0xFF) << 8) | (day & 0xFF);
}

int date_cmp(date_t a, date_t b)
{
    return a - b;
}

char *date_to_str(date_t date)
{
    // dd-mm-yyyy
    char *str = (char *)calloc(sizeof(char), sizeof("dd-mm-yyyy"));
    int year = (date >> 16) & 0xFFFF;
    int month = (date >> 8) & 0xFF;
    int day = date & 0xFF;
    sprintf(str, "%02d-%02d-%04d", day, month, year);
    return str;
}
