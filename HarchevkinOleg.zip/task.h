#ifndef TASK_H
#define TASK_H
#include "date.h"
#include <stdlib.h>

typedef enum status
{
    TODO,
    IN_PROGRESS,
    DONE,
} status_t;

typedef enum priority
{
    LOW,
    MEDIUM,
    HIGH,
} priority_t;

typedef struct task
{
    char *name;
    date_t deadline;
    status_t status;
    priority_t priority;
} task_t;

typedef struct tasks_arr
{
    task_t **items;
    size_t len;
    size_t cap;
} tasks_arr_t;

task_t *task_new(char *name, date_t deadline, status_t status, priority_t priority);
void task_free(task_t *task);

tasks_arr_t tasks_arr_new(size_t cap);
void tasks_arr_free(tasks_arr_t tasks);
tasks_arr_t tasks_arr_append(tasks_arr_t tasks, char *name, date_t deadline, status_t status, priority_t priority);
tasks_arr_t tasks_arr_sort_priority(tasks_arr_t tasks);
tasks_arr_t tasks_arr_filter_status(tasks_arr_t tasks, status_t status);
tasks_arr_t tasks_arr_filter_priority(tasks_arr_t tasks, priority_t priority);
tasks_arr_t tasks_arr_filter_overdue(tasks_arr_t tasks, date_t today);
tasks_arr_t tasks_arr_filter_highest_priority(tasks_arr_t tasks);

void tasks_arr_print(tasks_arr_t tasks, date_t today);

#endif