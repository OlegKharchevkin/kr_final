#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "task.h"
#include "date.h"

void clear_input(void) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

date_t input_date(const char *prompt) {
    int day, month, year;
    printf("%s", prompt);
    while (1) {
        if (scanf("%d-%d-%d", &day, &month, &year) == 3) {
            if (day >= 1 && day <= 31 && month >= 1 && month <= 12 && year >= 1900 && year <= 2100) {
                clear_input();
                return date_new(year, month, day);
            }
        }
        printf("Invalid format! Use DD-MM-YYYY: ");
        clear_input();
    }
}

priority_t input_priority(void) {
    int choice;
    printf("Priority:\n1. HIGH\n2. MEDIUM\n3. LOW\nChoose (1-3): ");
    while (1) {
        if (scanf("%d", &choice) == 1 && choice >= 1 && choice <= 3) {
            clear_input();
            return (priority_t)choice;
        }
        printf("Invalid input! Enter 1-3: ");
        clear_input();
    }
}

status_t input_status(void) {
    int choice;
    printf("Status:\n1. TODO\n2. IN_PROGRESS\n3. DONE\nChoose (1-3): ");
    while (1) {
        if (scanf("%d", &choice) == 1 && choice >= 1 && choice <= 3) {
            clear_input();
            return (status_t)choice;
        }
        printf("Invalid input! Enter 1-3: ");
        clear_input();
    }
}

char* input_name(void) {
    char buffer[256];
    printf("Task name: ");
    fgets(buffer, sizeof(buffer), stdin);
    buffer[strcspn(buffer, "\n")] = '\0';
    if (strlen(buffer) == 0) strcpy(buffer, "Unnamed");
    return strdup(buffer);
}

enum MenuItem {
    MENU_PRINT_ALL,
    MENU_ADD_TASK,
    MENU_CHANGE_STATUS,
    MENU_SORT_PRIORITY,
    MENU_FILTER_STATUS,
    MENU_HIGHEST_PRIORITY,
    MENU_OVERDUE,
    MENU_EXIT
};

const char *menu_items[] = {
    "Print all tasks",
    "Add task",
    "Change task status",
    "Sort by priority",
    "Filter by status",
    "Show highest priority tasks",
    "Show overdue tasks",
    "Exit"
};

int menu_input(void) {
    int choice;
    while (1) {
        printf("\nTASK MANAGER\n");
        for (int i = 0; i < sizeof(menu_items) / sizeof(char *); i++)
            printf("%d. %s\n", i + 1, menu_items[i]);
        printf("\nSelect menu item: ");
        if (scanf("%d", &choice) == 1 && choice >= 1 && choice <= (int)(sizeof(menu_items)/sizeof(char *))) {
            clear_input();
            return choice - 1;
        }
        clear_input();
        printf("Invalid input!\n\n");
    }
}

int main(void) {
    tasks_arr_t tasks = tasks_arr_new(16);
    if (!tasks.items) {
        printf("Failed to initialize task list.\n");
        return 1;
    }

    date_t today = input_date("Enter today's date (DD-MM-YYYY): ");

    while (1) {
        switch (menu_input()) {
            case MENU_PRINT_ALL:
                printf("\n===== ALL TASKS =====\n");
                tasks_arr_print(tasks, today);
                break;

            case MENU_ADD_TASK: {
                char *name = input_name();
                priority_t prio = input_priority();
                status_t stat = input_status();
                printf("Has deadline? (y/n): ");
                char ans;
                scanf(" %c", &ans);
                clear_input();
                date_t deadline = DATE_NULL;
                if (ans == 'y' || ans == 'Y') {
                    deadline = input_date("Enter deadline (DD-MM-YYYY): ");
                }
                tasks_arr_t new_tasks = tasks_arr_append(tasks, name, deadline, stat, prio);
                free(name);
                if (!new_tasks.items) {
                    printf("Error adding task!\n");
                    tasks_arr_free(tasks);
                    exit(1);
                }
                tasks = new_tasks;
                printf("Task added.\n");
                break;
            }

            case MENU_CHANGE_STATUS: {
                if (tasks.len == 0) {
                    printf("No tasks to change.\n");
                    break;
                }
                printf("\n===== ALL TASKS =====\n");
                tasks_arr_print(tasks, today);
                printf("Enter task number to change (1-%zu): ", tasks.len);
                size_t idx;
                if (scanf("%zu", &idx) != 1 || idx < 1 || idx > tasks.len) {
                    printf("Invalid number.\n");
                    clear_input();
                    break;
                }
                clear_input();
                status_t new_status = input_status();
                tasks.items[idx-1]->status = new_status;
                printf("Status of \"%s\" changed to %d.\n", tasks.items[idx-1]->name, new_status);
                break;
            }

            case MENU_SORT_PRIORITY:
                tasks = tasks_arr_sort_priority(tasks);
                printf("Tasks sorted by priority (HIGH to LOW).\n");
                break;

            case MENU_FILTER_STATUS: {
                status_t filter_stat = input_status();
                tasks_arr_t filtered = tasks_arr_filter_status(tasks, filter_stat);
                printf("\n===== FILTERED BY STATUS =====\n");
                tasks_arr_print(filtered, today);
                tasks_arr_free(filtered);
                break;
            }

            case MENU_HIGHEST_PRIORITY: {
                tasks_arr_t highest = tasks_arr_filter_highest_priority(tasks);
                printf("\n===== HIGHEST PRIORITY TASKS =====\n");
                tasks_arr_print(highest, today);
                tasks_arr_free(highest);
                break;
            }

            case MENU_OVERDUE: {
                tasks_arr_t overdue = tasks_arr_filter_overdue(tasks, today);
                printf("\n===== OVERDUE TASKS =====\n");
                tasks_arr_print(overdue, today);
                tasks_arr_free(overdue);
                break;
            }

            case MENU_EXIT:
                tasks_arr_free(tasks);
                printf("Goodbye!\n");
                return 0;
        }
    }
}